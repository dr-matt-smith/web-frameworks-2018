<?php

/* @WebProfiler/Icon/cache.svg */
class __TwigTemplate_b1350f9885e25ee05bb6d9864e18f00aad04d6ad6b85911fbab6d5fa74423fc6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_410ef1a432aac4101c08332e0f1d10c9f8efbb2e9e387fbaf4cac165c873fa23 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_410ef1a432aac4101c08332e0f1d10c9f8efbb2e9e387fbaf4cac165c873fa23->enter($__internal_410ef1a432aac4101c08332e0f1d10c9f8efbb2e9e387fbaf4cac165c873fa23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/cache.svg"));

        $__internal_42f9ec78d4d2b10309425758f7586426e53d3bc47f9f6a9730cc838f2782eb31 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_42f9ec78d4d2b10309425758f7586426e53d3bc47f9f6a9730cc838f2782eb31->enter($__internal_42f9ec78d4d2b10309425758f7586426e53d3bc47f9f6a9730cc838f2782eb31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/cache.svg"));

        // line 1
        echo "<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
<path fill=\"#AAA\" d=\"M2.26 6.09l9.06-4.67a1.49 1.49 0 0 1 1.37 0l9.06 4.67a1.49 1.49 0 0 1 0 2.65l-9.06 4.67a1.49 1.49 0 0 1-1.37 0L2.26 8.74a1.49 1.49 0 0 1 0-2.65zM20.55 11L12 15.39 3.45 11a1.36 1.36 0 0 0-1.25 2.42l9.17 4.73a1.36 1.36 0 0 0 1.25 0l9.17-4.73A1.36 1.36 0 0 0 20.55 11zm0 4.47L12 19.86l-8.55-4.41a1.36 1.36 0 0 0-1.25 2.42l9.17 4.73a1.36 1.36 0 0 0 1.25 0l9.17-4.73a1.36 1.36 0 0 0-1.25-2.42z\"/>
</svg>
";
        
        $__internal_410ef1a432aac4101c08332e0f1d10c9f8efbb2e9e387fbaf4cac165c873fa23->leave($__internal_410ef1a432aac4101c08332e0f1d10c9f8efbb2e9e387fbaf4cac165c873fa23_prof);

        
        $__internal_42f9ec78d4d2b10309425758f7586426e53d3bc47f9f6a9730cc838f2782eb31->leave($__internal_42f9ec78d4d2b10309425758f7586426e53d3bc47f9f6a9730cc838f2782eb31_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Icon/cache.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
<path fill=\"#AAA\" d=\"M2.26 6.09l9.06-4.67a1.49 1.49 0 0 1 1.37 0l9.06 4.67a1.49 1.49 0 0 1 0 2.65l-9.06 4.67a1.49 1.49 0 0 1-1.37 0L2.26 8.74a1.49 1.49 0 0 1 0-2.65zM20.55 11L12 15.39 3.45 11a1.36 1.36 0 0 0-1.25 2.42l9.17 4.73a1.36 1.36 0 0 0 1.25 0l9.17-4.73A1.36 1.36 0 0 0 20.55 11zm0 4.47L12 19.86l-8.55-4.41a1.36 1.36 0 0 0-1.25 2.42l9.17 4.73a1.36 1.36 0 0 0 1.25 0l9.17-4.73a1.36 1.36 0 0 0-1.25-2.42z\"/>
</svg>
", "@WebProfiler/Icon/cache.svg", "/Users/matt/Library/Mobile Documents/com~apple~CloudDocs/91_UNITS/UNITS_PHP_4_frmwrks/lab_sheets/web3-lab-sheets-codes/lab05/basic6/vendor/symfony/web-profiler-bundle/Resources/views/Icon/cache.svg");
    }
}
