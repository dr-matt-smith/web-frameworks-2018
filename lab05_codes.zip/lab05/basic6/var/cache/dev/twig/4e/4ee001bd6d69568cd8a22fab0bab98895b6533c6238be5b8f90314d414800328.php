<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_e97a89905328efa8dec6d9fd48d5d3215c6609fa3f91774b84344c7bae5f4573 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8a13057d2652740e0becba678fb13db53e917d2bd1a4670e5f7e69ada8febfbf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8a13057d2652740e0becba678fb13db53e917d2bd1a4670e5f7e69ada8febfbf->enter($__internal_8a13057d2652740e0becba678fb13db53e917d2bd1a4670e5f7e69ada8febfbf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_10d1c264332ea57077f8d551e0ade3e65e2f43d1296deedc7515631c721eafc1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_10d1c264332ea57077f8d551e0ade3e65e2f43d1296deedc7515631c721eafc1->enter($__internal_10d1c264332ea57077f8d551e0ade3e65e2f43d1296deedc7515631c721eafc1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8a13057d2652740e0becba678fb13db53e917d2bd1a4670e5f7e69ada8febfbf->leave($__internal_8a13057d2652740e0becba678fb13db53e917d2bd1a4670e5f7e69ada8febfbf_prof);

        
        $__internal_10d1c264332ea57077f8d551e0ade3e65e2f43d1296deedc7515631c721eafc1->leave($__internal_10d1c264332ea57077f8d551e0ade3e65e2f43d1296deedc7515631c721eafc1_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_0c2902a5002958511e2b3ac8a094f391552b9c63fd86436e016dd5d4bddc51cf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0c2902a5002958511e2b3ac8a094f391552b9c63fd86436e016dd5d4bddc51cf->enter($__internal_0c2902a5002958511e2b3ac8a094f391552b9c63fd86436e016dd5d4bddc51cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_b7aa532353cfbb5fb9c5a8b86db0f668a00ca7abb26fee984776e0aa10f9ab7d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b7aa532353cfbb5fb9c5a8b86db0f668a00ca7abb26fee984776e0aa10f9ab7d->enter($__internal_b7aa532353cfbb5fb9c5a8b86db0f668a00ca7abb26fee984776e0aa10f9ab7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_b7aa532353cfbb5fb9c5a8b86db0f668a00ca7abb26fee984776e0aa10f9ab7d->leave($__internal_b7aa532353cfbb5fb9c5a8b86db0f668a00ca7abb26fee984776e0aa10f9ab7d_prof);

        
        $__internal_0c2902a5002958511e2b3ac8a094f391552b9c63fd86436e016dd5d4bddc51cf->leave($__internal_0c2902a5002958511e2b3ac8a094f391552b9c63fd86436e016dd5d4bddc51cf_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_a5f55d62eb1b67eae85baf8b1366af0852f777dc845822d8584963a1b329ab53 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a5f55d62eb1b67eae85baf8b1366af0852f777dc845822d8584963a1b329ab53->enter($__internal_a5f55d62eb1b67eae85baf8b1366af0852f777dc845822d8584963a1b329ab53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_d9c5434f75644ba0bd890754922976045ecbac83cac14ae898c1f3b6f051008b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d9c5434f75644ba0bd890754922976045ecbac83cac14ae898c1f3b6f051008b->enter($__internal_d9c5434f75644ba0bd890754922976045ecbac83cac14ae898c1f3b6f051008b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_d9c5434f75644ba0bd890754922976045ecbac83cac14ae898c1f3b6f051008b->leave($__internal_d9c5434f75644ba0bd890754922976045ecbac83cac14ae898c1f3b6f051008b_prof);

        
        $__internal_a5f55d62eb1b67eae85baf8b1366af0852f777dc845822d8584963a1b329ab53->leave($__internal_a5f55d62eb1b67eae85baf8b1366af0852f777dc845822d8584963a1b329ab53_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_d8c73c40ae41a0c52ff199c367131ee197e445056379c809fe4d3dd39eb0e737 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d8c73c40ae41a0c52ff199c367131ee197e445056379c809fe4d3dd39eb0e737->enter($__internal_d8c73c40ae41a0c52ff199c367131ee197e445056379c809fe4d3dd39eb0e737_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_6418e4ef3a473c3b0f8401c4bd2ce0df7e95a4cc5902e7e39d476afe90d3f0dd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6418e4ef3a473c3b0f8401c4bd2ce0df7e95a4cc5902e7e39d476afe90d3f0dd->enter($__internal_6418e4ef3a473c3b0f8401c4bd2ce0df7e95a4cc5902e7e39d476afe90d3f0dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 13, $this->getSourceContext()); })()))));
        echo "
";
        
        $__internal_6418e4ef3a473c3b0f8401c4bd2ce0df7e95a4cc5902e7e39d476afe90d3f0dd->leave($__internal_6418e4ef3a473c3b0f8401c4bd2ce0df7e95a4cc5902e7e39d476afe90d3f0dd_prof);

        
        $__internal_d8c73c40ae41a0c52ff199c367131ee197e445056379c809fe4d3dd39eb0e737->leave($__internal_d8c73c40ae41a0c52ff199c367131ee197e445056379c809fe4d3dd39eb0e737_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/Users/matt/Library/Mobile Documents/com~apple~CloudDocs/91_UNITS/UNITS_PHP_4_frmwrks/lab_sheets/web3-lab-sheets-codes/lab05/basic6/vendor/symfony/web-profiler-bundle/Resources/views/Collector/router.html.twig");
    }
}
