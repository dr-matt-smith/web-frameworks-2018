<?php

/* @WebProfiler/Collector/ajax.html.twig */
class __TwigTemplate_cdbcd99668931d05ded4b2d15023c61023f38130686b954976b033229d78429d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/ajax.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bb0e194f8a0b72b822caefddb99b9d0d6aff182eb359abccc68f35442a24a4dc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bb0e194f8a0b72b822caefddb99b9d0d6aff182eb359abccc68f35442a24a4dc->enter($__internal_bb0e194f8a0b72b822caefddb99b9d0d6aff182eb359abccc68f35442a24a4dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/ajax.html.twig"));

        $__internal_7993ff9571fc3026baa9a16d4c825fe3dc20384354f364f9aa4d7304ba79e2f5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7993ff9571fc3026baa9a16d4c825fe3dc20384354f364f9aa4d7304ba79e2f5->enter($__internal_7993ff9571fc3026baa9a16d4c825fe3dc20384354f364f9aa4d7304ba79e2f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/ajax.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bb0e194f8a0b72b822caefddb99b9d0d6aff182eb359abccc68f35442a24a4dc->leave($__internal_bb0e194f8a0b72b822caefddb99b9d0d6aff182eb359abccc68f35442a24a4dc_prof);

        
        $__internal_7993ff9571fc3026baa9a16d4c825fe3dc20384354f364f9aa4d7304ba79e2f5->leave($__internal_7993ff9571fc3026baa9a16d4c825fe3dc20384354f364f9aa4d7304ba79e2f5_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_2a90bc50cb1cfd6850d653a3f276629a2eac6a488bd85d978d1dc3b4076f8082 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2a90bc50cb1cfd6850d653a3f276629a2eac6a488bd85d978d1dc3b4076f8082->enter($__internal_2a90bc50cb1cfd6850d653a3f276629a2eac6a488bd85d978d1dc3b4076f8082_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_dd86db583af764f043e748b3099a5209db66e7b9a3487c01c8eed1f6b11a42c2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd86db583af764f043e748b3099a5209db66e7b9a3487c01c8eed1f6b11a42c2->enter($__internal_dd86db583af764f043e748b3099a5209db66e7b9a3487c01c8eed1f6b11a42c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        // line 4
        echo "    ";
        ob_start();
        // line 5
        echo "        ";
        echo twig_include($this->env, $context, "@WebProfiler/Icon/ajax.svg");
        echo "
        <span class=\"sf-toolbar-value sf-toolbar-ajax-request-counter\">0</span>
    ";
        $context["icon"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 8
        echo "
    ";
        // line 9
        $context["text"] = ('' === $tmp = "        <div class=\"sf-toolbar-info-piece\">
            <b class=\"sf-toolbar-ajax-info\"></b>
        </div>
        <div class=\"sf-toolbar-info-piece\">
            <table class=\"sf-toolbar-ajax-requests\">
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>URL</th>
                        <th>Time</th>
                        <th>Profile</th>
                    </tr>
                </thead>
                <tbody class=\"sf-toolbar-ajax-request-list\"></tbody>
            </table>
        </div>
    ") ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 29
        echo "
    ";
        // line 30
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/toolbar_item.html.twig", array("link" => false));
        echo "
";
        
        $__internal_dd86db583af764f043e748b3099a5209db66e7b9a3487c01c8eed1f6b11a42c2->leave($__internal_dd86db583af764f043e748b3099a5209db66e7b9a3487c01c8eed1f6b11a42c2_prof);

        
        $__internal_2a90bc50cb1cfd6850d653a3f276629a2eac6a488bd85d978d1dc3b4076f8082->leave($__internal_2a90bc50cb1cfd6850d653a3f276629a2eac6a488bd85d978d1dc3b4076f8082_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/ajax.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 30,  82 => 29,  62 => 9,  59 => 8,  52 => 5,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}
    {% set icon %}
        {{ include('@WebProfiler/Icon/ajax.svg') }}
        <span class=\"sf-toolbar-value sf-toolbar-ajax-request-counter\">0</span>
    {% endset %}

    {% set text %}
        <div class=\"sf-toolbar-info-piece\">
            <b class=\"sf-toolbar-ajax-info\"></b>
        </div>
        <div class=\"sf-toolbar-info-piece\">
            <table class=\"sf-toolbar-ajax-requests\">
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>URL</th>
                        <th>Time</th>
                        <th>Profile</th>
                    </tr>
                </thead>
                <tbody class=\"sf-toolbar-ajax-request-list\"></tbody>
            </table>
        </div>
    {% endset %}

    {{ include('@WebProfiler/Profiler/toolbar_item.html.twig', { link: false }) }}
{% endblock %}
", "@WebProfiler/Collector/ajax.html.twig", "/Users/matt/Library/Mobile Documents/com~apple~CloudDocs/91_UNITS/UNITS_PHP_4_frmwrks/lab_sheets/web3-lab-sheets-codes/lab05/basic6/vendor/symfony/web-profiler-bundle/Resources/views/Collector/ajax.html.twig");
    }
}
