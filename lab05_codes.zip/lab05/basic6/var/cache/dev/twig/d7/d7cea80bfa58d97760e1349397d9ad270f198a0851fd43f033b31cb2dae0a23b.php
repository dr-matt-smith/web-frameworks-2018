<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_7d3e353b8a883698c2f2181afbb222c39a20950f1d137a39b7696a67c6dc2e2f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_56e0e811084287cd68d80b1b0960afcb127070117e2baef283d890bfaebc5ec5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_56e0e811084287cd68d80b1b0960afcb127070117e2baef283d890bfaebc5ec5->enter($__internal_56e0e811084287cd68d80b1b0960afcb127070117e2baef283d890bfaebc5ec5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_d46e35c11eea227605052b1db54e55a8b85bce0555450805ea184548a5b42856 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d46e35c11eea227605052b1db54e55a8b85bce0555450805ea184548a5b42856->enter($__internal_d46e35c11eea227605052b1db54e55a8b85bce0555450805ea184548a5b42856_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_56e0e811084287cd68d80b1b0960afcb127070117e2baef283d890bfaebc5ec5->leave($__internal_56e0e811084287cd68d80b1b0960afcb127070117e2baef283d890bfaebc5ec5_prof);

        
        $__internal_d46e35c11eea227605052b1db54e55a8b85bce0555450805ea184548a5b42856->leave($__internal_d46e35c11eea227605052b1db54e55a8b85bce0555450805ea184548a5b42856_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_813892ccc60f0019c69cbe9b637fec6cb0c4938de1b2481c05af6a35ba034344 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_813892ccc60f0019c69cbe9b637fec6cb0c4938de1b2481c05af6a35ba034344->enter($__internal_813892ccc60f0019c69cbe9b637fec6cb0c4938de1b2481c05af6a35ba034344_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_0a32d705e2abff337d0c98e0cfa7d99f8144bef0ed7b408240358badc8e86577 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0a32d705e2abff337d0c98e0cfa7d99f8144bef0ed7b408240358badc8e86577->enter($__internal_0a32d705e2abff337d0c98e0cfa7d99f8144bef0ed7b408240358badc8e86577_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 4, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 6, $this->getSourceContext()); })()))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_0a32d705e2abff337d0c98e0cfa7d99f8144bef0ed7b408240358badc8e86577->leave($__internal_0a32d705e2abff337d0c98e0cfa7d99f8144bef0ed7b408240358badc8e86577_prof);

        
        $__internal_813892ccc60f0019c69cbe9b637fec6cb0c4938de1b2481c05af6a35ba034344->leave($__internal_813892ccc60f0019c69cbe9b637fec6cb0c4938de1b2481c05af6a35ba034344_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_64a91d29fdc1ce2e5f500e63ed084b1fd17dad728174b1c3b50110a8a2f24dac = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_64a91d29fdc1ce2e5f500e63ed084b1fd17dad728174b1c3b50110a8a2f24dac->enter($__internal_64a91d29fdc1ce2e5f500e63ed084b1fd17dad728174b1c3b50110a8a2f24dac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_f0bc24a5bd8a4ae57cb296051bd145b25ce7ada1796d6e4259ab693240292787 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f0bc24a5bd8a4ae57cb296051bd145b25ce7ada1796d6e4259ab693240292787->enter($__internal_f0bc24a5bd8a4ae57cb296051bd145b25ce7ada1796d6e4259ab693240292787_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo ((twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 13, $this->getSourceContext()); })()), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 16, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_f0bc24a5bd8a4ae57cb296051bd145b25ce7ada1796d6e4259ab693240292787->leave($__internal_f0bc24a5bd8a4ae57cb296051bd145b25ce7ada1796d6e4259ab693240292787_prof);

        
        $__internal_64a91d29fdc1ce2e5f500e63ed084b1fd17dad728174b1c3b50110a8a2f24dac->leave($__internal_64a91d29fdc1ce2e5f500e63ed084b1fd17dad728174b1c3b50110a8a2f24dac_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_7bf957dc235e3e0bc250ee0b56e9d02a57461772666eea77e7a4c1303a5516a4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7bf957dc235e3e0bc250ee0b56e9d02a57461772666eea77e7a4c1303a5516a4->enter($__internal_7bf957dc235e3e0bc250ee0b56e9d02a57461772666eea77e7a4c1303a5516a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_bb047059f9de182a872800713040c8d73a8266f750f50bb85587f0e4b5c1ee99 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bb047059f9de182a872800713040c8d73a8266f750f50bb85587f0e4b5c1ee99->enter($__internal_bb047059f9de182a872800713040c8d73a8266f750f50bb85587f0e4b5c1ee99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 27, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 33, $this->getSourceContext()); })()))));
            echo "
        </div>
    ";
        }
        
        $__internal_bb047059f9de182a872800713040c8d73a8266f750f50bb85587f0e4b5c1ee99->leave($__internal_bb047059f9de182a872800713040c8d73a8266f750f50bb85587f0e4b5c1ee99_prof);

        
        $__internal_7bf957dc235e3e0bc250ee0b56e9d02a57461772666eea77e7a4c1303a5516a4->leave($__internal_7bf957dc235e3e0bc250ee0b56e9d02a57461772666eea77e7a4c1303a5516a4_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/Users/matt/Library/Mobile Documents/com~apple~CloudDocs/91_UNITS/UNITS_PHP_4_frmwrks/lab_sheets/web3-lab-sheets-codes/lab05/basic6/vendor/symfony/web-profiler-bundle/Resources/views/Collector/exception.html.twig");
    }
}
