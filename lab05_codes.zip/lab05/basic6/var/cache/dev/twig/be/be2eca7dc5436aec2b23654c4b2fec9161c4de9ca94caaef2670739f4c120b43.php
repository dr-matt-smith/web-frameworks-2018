<?php

/* product/show.html.twig */
class __TwigTemplate_c7709cbbe55d295b0a9464643c4cb970f89c339ff2408ae159c335804a57c369 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "product/show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9cbcf857ad160db6cc5c14d6a1ec4f4aac196d23fc76fb2c09d95aaaca823a28 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9cbcf857ad160db6cc5c14d6a1ec4f4aac196d23fc76fb2c09d95aaaca823a28->enter($__internal_9cbcf857ad160db6cc5c14d6a1ec4f4aac196d23fc76fb2c09d95aaaca823a28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/show.html.twig"));

        $__internal_819d61890a9e77cf05373454e002db51902cad7675c13125ed8cd058e96449d5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_819d61890a9e77cf05373454e002db51902cad7675c13125ed8cd058e96449d5->enter($__internal_819d61890a9e77cf05373454e002db51902cad7675c13125ed8cd058e96449d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9cbcf857ad160db6cc5c14d6a1ec4f4aac196d23fc76fb2c09d95aaaca823a28->leave($__internal_9cbcf857ad160db6cc5c14d6a1ec4f4aac196d23fc76fb2c09d95aaaca823a28_prof);

        
        $__internal_819d61890a9e77cf05373454e002db51902cad7675c13125ed8cd058e96449d5->leave($__internal_819d61890a9e77cf05373454e002db51902cad7675c13125ed8cd058e96449d5_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_019c9095b47c4a1f28d3a77c2fc287ff3836454121fff3e1f830d454acb12c02 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_019c9095b47c4a1f28d3a77c2fc287ff3836454121fff3e1f830d454acb12c02->enter($__internal_019c9095b47c4a1f28d3a77c2fc287ff3836454121fff3e1f830d454acb12c02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_0286f5d5366961f2864c6f0bf98b07fd7d35d199dec7aa8e0f95b2369534b587 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0286f5d5366961f2864c6f0bf98b07fd7d35d199dec7aa8e0f95b2369534b587->enter($__internal_0286f5d5366961f2864c6f0bf98b07fd7d35d199dec7aa8e0f95b2369534b587_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Product SHOW page</h1>

    <p>
        id = ";
        // line 7
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["product"]) || array_key_exists("product", $context) ? $context["product"] : (function () { throw new Twig_Error_Runtime('Variable "product" does not exist.', 7, $this->getSourceContext()); })()), "id", array()), "html", null, true);
        echo "
        <br>
        description = ";
        // line 9
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["product"]) || array_key_exists("product", $context) ? $context["product"] : (function () { throw new Twig_Error_Runtime('Variable "product" does not exist.', 9, $this->getSourceContext()); })()), "description", array()), "html", null, true);
        echo "
        <br>
        price = &euro; ";
        // line 11
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["product"]) || array_key_exists("product", $context) ? $context["product"] : (function () { throw new Twig_Error_Runtime('Variable "product" does not exist.', 11, $this->getSourceContext()); })()), "price", array()), "html", null, true);
        echo "
        <br>
        category = ";
        // line 13
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["product"]) || array_key_exists("product", $context) ? $context["product"] : (function () { throw new Twig_Error_Runtime('Variable "product" does not exist.', 13, $this->getSourceContext()); })()), "category", array()), "name", array()), "html", null, true);
        echo "
    </p>
";
        
        $__internal_0286f5d5366961f2864c6f0bf98b07fd7d35d199dec7aa8e0f95b2369534b587->leave($__internal_0286f5d5366961f2864c6f0bf98b07fd7d35d199dec7aa8e0f95b2369534b587_prof);

        
        $__internal_019c9095b47c4a1f28d3a77c2fc287ff3836454121fff3e1f830d454acb12c02->leave($__internal_019c9095b47c4a1f28d3a77c2fc287ff3836454121fff3e1f830d454acb12c02_prof);

    }

    public function getTemplateName()
    {
        return "product/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  69 => 13,  64 => 11,  59 => 9,  54 => 7,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Product SHOW page</h1>

    <p>
        id = {{ product.id }}
        <br>
        description = {{ product.description }}
        <br>
        price = &euro; {{ product.price }}
        <br>
        category = {{ product.category.name }}
    </p>
{% endblock %}", "product/show.html.twig", "/Users/matt/Library/Mobile Documents/com~apple~CloudDocs/91_UNITS/UNITS_PHP_4_frmwrks/lab_sheets/web3-lab-sheets-codes/lab05/basic6/templates/product/show.html.twig");
    }
}
