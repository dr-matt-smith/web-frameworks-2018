<?php

/* base.html.twig */
class __TwigTemplate_9ff0627068b2f7f9798b4112611d1d6767625ec20e62744218ccf866a5e95b02 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2c57f01a5577f32b578b36dd6421a147778eb124b966c8ed7aae37672bca78c9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2c57f01a5577f32b578b36dd6421a147778eb124b966c8ed7aae37672bca78c9->enter($__internal_2c57f01a5577f32b578b36dd6421a147778eb124b966c8ed7aae37672bca78c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_f1a3bc1c7955bb76ff2cdfc6f9a5baa5430459350ac0c5ac022bc02809307fb3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f1a3bc1c7955bb76ff2cdfc6f9a5baa5430459350ac0c5ac022bc02809307fb3->enter($__internal_f1a3bc1c7955bb76ff2cdfc6f9a5baa5430459350ac0c5ac022bc02809307fb3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "    </head>
    <body>
        ";
        // line 9
        $this->displayBlock('body', $context, $blocks);
        // line 10
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 11
        echo "    </body>
</html>
";
        
        $__internal_2c57f01a5577f32b578b36dd6421a147778eb124b966c8ed7aae37672bca78c9->leave($__internal_2c57f01a5577f32b578b36dd6421a147778eb124b966c8ed7aae37672bca78c9_prof);

        
        $__internal_f1a3bc1c7955bb76ff2cdfc6f9a5baa5430459350ac0c5ac022bc02809307fb3->leave($__internal_f1a3bc1c7955bb76ff2cdfc6f9a5baa5430459350ac0c5ac022bc02809307fb3_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_8a8b3699e20eeef70645ecb70f3c661b327384109ec45ba2be29fcebc0ae76e7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8a8b3699e20eeef70645ecb70f3c661b327384109ec45ba2be29fcebc0ae76e7->enter($__internal_8a8b3699e20eeef70645ecb70f3c661b327384109ec45ba2be29fcebc0ae76e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_ab18495b7a2630d6fc63d3f15e447746ee847f2024d9e2d69d0f0d3750a64a0e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ab18495b7a2630d6fc63d3f15e447746ee847f2024d9e2d69d0f0d3750a64a0e->enter($__internal_ab18495b7a2630d6fc63d3f15e447746ee847f2024d9e2d69d0f0d3750a64a0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_ab18495b7a2630d6fc63d3f15e447746ee847f2024d9e2d69d0f0d3750a64a0e->leave($__internal_ab18495b7a2630d6fc63d3f15e447746ee847f2024d9e2d69d0f0d3750a64a0e_prof);

        
        $__internal_8a8b3699e20eeef70645ecb70f3c661b327384109ec45ba2be29fcebc0ae76e7->leave($__internal_8a8b3699e20eeef70645ecb70f3c661b327384109ec45ba2be29fcebc0ae76e7_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_282b4ae759f4f2579d9b13b15a5742f4db7fcc4d011ee2ff89d7d7fae880fcb2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_282b4ae759f4f2579d9b13b15a5742f4db7fcc4d011ee2ff89d7d7fae880fcb2->enter($__internal_282b4ae759f4f2579d9b13b15a5742f4db7fcc4d011ee2ff89d7d7fae880fcb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_ff822fa44369d166d88c2f556e74177ff38f97f1146efef0ef44ac33328362d6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ff822fa44369d166d88c2f556e74177ff38f97f1146efef0ef44ac33328362d6->enter($__internal_ff822fa44369d166d88c2f556e74177ff38f97f1146efef0ef44ac33328362d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_ff822fa44369d166d88c2f556e74177ff38f97f1146efef0ef44ac33328362d6->leave($__internal_ff822fa44369d166d88c2f556e74177ff38f97f1146efef0ef44ac33328362d6_prof);

        
        $__internal_282b4ae759f4f2579d9b13b15a5742f4db7fcc4d011ee2ff89d7d7fae880fcb2->leave($__internal_282b4ae759f4f2579d9b13b15a5742f4db7fcc4d011ee2ff89d7d7fae880fcb2_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_f1000e71102958f4033de8f3c81958939ff0b470490fc22ee3da43a43e6cd72d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f1000e71102958f4033de8f3c81958939ff0b470490fc22ee3da43a43e6cd72d->enter($__internal_f1000e71102958f4033de8f3c81958939ff0b470490fc22ee3da43a43e6cd72d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_8d65f9e11a7fef51d332774c722cbe57aa018b21ee8282501a9210a8b9959692 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8d65f9e11a7fef51d332774c722cbe57aa018b21ee8282501a9210a8b9959692->enter($__internal_8d65f9e11a7fef51d332774c722cbe57aa018b21ee8282501a9210a8b9959692_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_8d65f9e11a7fef51d332774c722cbe57aa018b21ee8282501a9210a8b9959692->leave($__internal_8d65f9e11a7fef51d332774c722cbe57aa018b21ee8282501a9210a8b9959692_prof);

        
        $__internal_f1000e71102958f4033de8f3c81958939ff0b470490fc22ee3da43a43e6cd72d->leave($__internal_f1000e71102958f4033de8f3c81958939ff0b470490fc22ee3da43a43e6cd72d_prof);

    }

    // line 10
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_783dff86b7a3a1e4eefc5817c9deab088c12614df8c0f1ee3a771b9322cf811a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_783dff86b7a3a1e4eefc5817c9deab088c12614df8c0f1ee3a771b9322cf811a->enter($__internal_783dff86b7a3a1e4eefc5817c9deab088c12614df8c0f1ee3a771b9322cf811a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_2e7dc642ff07d92820204a86ac571bd72bfb3a73f78f99a46ebfa0c3c795ec55 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e7dc642ff07d92820204a86ac571bd72bfb3a73f78f99a46ebfa0c3c795ec55->enter($__internal_2e7dc642ff07d92820204a86ac571bd72bfb3a73f78f99a46ebfa0c3c795ec55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_2e7dc642ff07d92820204a86ac571bd72bfb3a73f78f99a46ebfa0c3c795ec55->leave($__internal_2e7dc642ff07d92820204a86ac571bd72bfb3a73f78f99a46ebfa0c3c795ec55_prof);

        
        $__internal_783dff86b7a3a1e4eefc5817c9deab088c12614df8c0f1ee3a771b9322cf811a->leave($__internal_783dff86b7a3a1e4eefc5817c9deab088c12614df8c0f1ee3a771b9322cf811a_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  114 => 10,  97 => 9,  80 => 6,  62 => 5,  50 => 11,  47 => 10,  45 => 9,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "/Users/matt/Library/Mobile Documents/com~apple~CloudDocs/91_UNITS/UNITS_PHP_4_frmwrks/lab_sheets/web3-lab-sheets-codes/lab05/basic6/templates/base.html.twig");
    }
}
